export type VariantStockQuery = {
  storeId?: string | number;
  productId?: string | number;
  variantId?: string | number;
};

/**
 * The current APK contains the query fragments `&storeId=` and `&variantId=`
 * adjacent to the recovered `ProductStocks/variant-stocks?` route. Keep the
 * builder explicit so we never invent IDs or send `undefined` to production.
 */
export function buildVariantStockQuery(input: VariantStockQuery): string {
  const params: string[] = [];
  if (input.productId !== undefined && input.productId !== '') {
    params.push(`productId=${encodeURIComponent(String(input.productId))}`);
  }
  if (input.storeId !== undefined && input.storeId !== '') {
    params.push(`storeId=${encodeURIComponent(String(input.storeId))}`);
  }
  if (input.variantId !== undefined && input.variantId !== '') {
    params.push(`variantId=${encodeURIComponent(String(input.variantId))}`);
  }
  return params.join('&');
}
