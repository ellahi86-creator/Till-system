import { BACKEND } from '../config/backend';
import type { CheckoutDraft } from '../domain/checkout';
import { getSession } from './session';
import { normalizeOrderSuccess, type OrderSuccess } from './postSale';

export type RecoveredOrderItem = {
  id: string;
  name: string;
  description?: string;
  purchasedPrice?: number;
  sellPrice: number;
  quantity: number;
  totalPrice: number;
  variantId?: string;
  discount: number;
  totalDiscount: number;
};

export type RecoveredOrderPayload = {
  subTotal: number;
  discount: number;
  discountAmount: number;
  itemDiscountAmount: number;
  totalDiscount: number;
  grandTotal: number;
  cardAmount: number;
  cashAmount: number;
  changeDueAmount: number;
  tenderedAmount: number;
  paymentMethod: string;
  notes: string;
  status: string;
  items: RecoveredOrderItem[];
};

function numberFromRaw(raw: Record<string, unknown> | undefined, ...keys: string[]): number | undefined {
  if (!raw) return undefined;
  for (const key of keys) {
    const value = raw[key];
    const parsed = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : NaN;
    if (Number.isFinite(parsed)) return parsed;
  }
  return undefined;
}

function stringFromRaw(raw: Record<string, unknown> | undefined, ...keys: string[]): string | undefined {
  if (!raw) return undefined;
  for (const key of keys) {
    const value = raw[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return undefined;
}

/**
 * Reconstructed from the current production Hermes bundle.
 * The original Checkout builds this object immediately before calling add_order().
 */
export function buildRecoveredOrderPayload(draft: CheckoutDraft): RecoveredOrderPayload {
  const itemDiscountAmount = 0;

  return {
    subTotal: draft.subtotal,
    discount: draft.discountPercent,
    discountAmount: draft.discountAmount,
    itemDiscountAmount,
    totalDiscount: draft.discountAmount + itemDiscountAmount,
    grandTotal: draft.total,
    cardAmount: draft.cardAmount,
    cashAmount: draft.cashAmount,
    changeDueAmount: draft.changeDue,
    tenderedAmount: draft.tenderedAmount,
    paymentMethod: draft.paymentMethod,
    notes: draft.receiptNotes || 'Generated via POS',
    status: draft.status,
    items: draft.lines.map(line => ({
      id: line.product.id,
      name: line.product.name,
      description: stringFromRaw(line.product.raw, 'description', 'Description'),
      purchasedPrice: numberFromRaw(line.product.raw, 'purchasedPrice', 'purchasePrice', 'costPrice'),
      sellPrice: line.product.price,
      quantity: line.quantity,
      totalPrice: Math.round(line.product.price * line.quantity * 100) / 100,
      variantId: line.variantId,
      discount: 0,
      totalDiscount: 0,
    })),
  };
}

export function validateRecoveredOrderPayload(payload: RecoveredOrderPayload): string[] {
  const issues: string[] = [];
  if (!payload.items.length) issues.push('Order has no items.');
  if (!payload.status) issues.push('Order status is missing.');
  if (payload.grandTotal < 0) issues.push('Grand total cannot be negative.');
  if (payload.tenderedAmount < payload.grandTotal && payload.status !== 'Void') {
    issues.push('Tendered amount is below the grand total.');
  }
  for (const [index, item] of payload.items.entries()) {
    if (!item.id) issues.push(`Item ${index + 1} is missing id.`);
    if (!(item.quantity > 0)) issues.push(`Item ${index + 1} has invalid quantity.`);
  }
  return issues;
}

export const RECOVERED_CREATE_ORDER_PATH = 'orders/';

export async function submitOrderSafely(draft: CheckoutDraft): Promise<OrderSuccess> {
  const payload = buildRecoveredOrderPayload(draft);
  const issues = validateRecoveredOrderPayload(payload);
  if (issues.length) throw new Error(`Order validation failed: ${issues.join(' ')}`);

  if (!BACKEND.liveWritesEnabled) {
    if (BACKEND.testMode) {
      const stamp = Date.now();
      return normalizeOrderSuccess({
        data: { id: `TEST-${stamp}`, orderNumber: `TEST-${String(stamp).slice(-6)}` },
        testMode: true,
        payload,
      });
    }
    throw new Error('Production order submission is blocked. The recovered production create route is orders/; enable only for an isolated live test.');
  }

  const session = getSession();
  if (!session?.accessToken) throw new Error('No authenticated POS session.');

  const response = await fetch(`${BACKEND.baseUrl.replace(/\/$/, '')}/${RECOVERED_CREATE_ORDER_PATH}`, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${session.accessToken}`,
    },
    body: JSON.stringify(payload),
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`POS order submission failed (${response.status}).`);
  }
  return normalizeOrderSuccess(body);
}
