export type PosUser = Record<string, unknown>;

export type PosSession = {
  accessToken: string;
  refreshToken?: string;
  user?: PosUser;
  storeId?: string | number;
  username?: string;
};

let currentSession: PosSession | null = null;

function idValue(value: unknown): string | number | undefined {
  if (typeof value === 'string' && value.trim()) return value.trim();
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  return undefined;
}

export function extractStoreId(user?: PosUser): string | number | undefined {
  if (!user) return undefined;

  // `user_info.storeId` is read directly by Dashboard in the production APK.
  const direct = idValue(user.storeId) ?? idValue(user.store_id) ?? idValue(user.StoreId);
  if (direct !== undefined) return direct;

  // Keep a defensive nested fallback for API envelopes that hydrate the same
  // store under a related object while preserving the production direct field.
  const store = user.store;
  if (store && typeof store === 'object' && !Array.isArray(store)) {
    const obj = store as Record<string, unknown>;
    return idValue(obj.id) ?? idValue(obj.storeId) ?? idValue(obj.store_id);
  }

  return undefined;
}

export function setSession(session: PosSession | null) {
  currentSession = session;
}

export function getSession(): PosSession | null {
  return currentSession;
}
