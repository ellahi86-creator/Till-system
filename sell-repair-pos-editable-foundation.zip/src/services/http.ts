import { BACKEND } from '../config/backend';
import { getSession } from './session';

export async function safeGet<T>(path: string): Promise<T> {
  if (!BACKEND.liveReadsEnabled) {
    throw new Error('Live API reads are disabled while the production API contract is being reconstructed.');
  }

  const session = getSession();
  const headers: Record<string, string> = { Accept: 'application/json' };

  // The APK contains an access_token and Bearer-auth flow, but the exact
  // header construction is still being verified. This is isolated here so
  // one change fixes all reads when confirmed.
  if (session?.accessToken) {
    headers.Authorization = `Bearer ${session.accessToken}`;
  }

  const response = await fetch(`${BACKEND.baseUrl.replace(/\/$/, '')}/${path.replace(/^\//, '')}`, {
    method: 'GET',
    headers,
  });

  if (!response.ok) {
    throw new Error(`POS API read failed (${response.status})`);
  }

  return response.json() as Promise<T>;
}
