import type { CheckoutDraft } from '../domain/checkout';
import type { CartLine } from '../domain/product';
import type { StockRecord } from '../domain/catalog';
import { buildReceiptText } from './receipt';
import { getProductVariants } from './posApi';
import { getSession } from './session';
import { printReceipt } from './printerService';

export type OrderSuccess = {
  orderId?: string | number;
  orderNumber?: string;
  raw: unknown;
};

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;
}

function firstRecord(value: unknown): Record<string, unknown> | null {
  const root = asRecord(value);
  if (!root) return null;
  const candidates = [root.data, root.result, root.order, root.value];
  for (const candidate of candidates) {
    const record = asRecord(candidate);
    if (record) return record;
  }
  return root;
}

function firstId(record: Record<string, unknown> | null): string | number | undefined {
  if (!record) return undefined;
  for (const key of ['id', 'orderId', 'order_id', 'Id']) {
    const value = record[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (typeof value === 'number' && Number.isFinite(value)) return value;
  }
  return undefined;
}

function firstOrderNumber(record: Record<string, unknown> | null): string | undefined {
  if (!record) return undefined;
  for (const key of ['orderNumber', 'order_number', 'number', 'invoiceNumber', 'invoiceNo']) {
    const value = record[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  }
  return undefined;
}

/**
 * The production APK saves an order then uses the returned order/number in the
 * receipt flow. The exact envelope can vary between API helpers, so unwrap the
 * common `data`/`result`/`order` shapes without inventing a value.
 */
export function normalizeOrderSuccess(body: unknown): OrderSuccess {
  const record = firstRecord(body);
  return {
    orderId: firstId(record),
    orderNumber: firstOrderNumber(record),
    raw: body,
  };
}

export function draftWithOrderNumber(draft: CheckoutDraft, success: OrderSuccess): CheckoutDraft {
  return success.orderNumber ? { ...draft, orderNumber: success.orderNumber } : draft;
}

export function resolvePrinterIp(...sources: Array<Record<string, unknown> | undefined | null>): string | undefined {
  for (const source of sources) {
    if (!source) continue;
    for (const key of ['printerIp', 'printerIP', 'printer_ip', 'epsonPrinterIp', 'epson_printer_ip']) {
      const value = source[key];
      if (typeof value === 'string' && value.trim()) return value.trim();
    }
  }
  return undefined;
}

export async function refreshSoldVariantStock(lines: CartLine[]): Promise<Record<string, StockRecord[]>> {
  const productIds = [...new Set(lines.map(line => line.product.id).filter(Boolean))];
  const storeId = getSession()?.storeId;
  const settled = await Promise.allSettled(
    productIds.map(async productId => [productId, await getProductVariants(productId, storeId)] as const),
  );

  const refreshed: Record<string, StockRecord[]> = {};
  for (const result of settled) {
    if (result.status === 'fulfilled') refreshed[result.value[0]] = result.value[1];
  }
  return refreshed;
}

export async function runPostSaleFlow(input: {
  draft: CheckoutDraft;
  responseBody: unknown;
  printerIp?: string;
  print?: boolean;
}): Promise<{
  success: OrderSuccess;
  finalDraft: CheckoutDraft;
  receiptText: string;
  refreshedStock: Record<string, StockRecord[]>;
  printed: boolean;
}> {
  const success = normalizeOrderSuccess(input.responseBody);
  const finalDraft = draftWithOrderNumber(input.draft, success);
  const receiptText = buildReceiptText(finalDraft);
  const refreshedStock = await refreshSoldVariantStock(finalDraft.lines);

  let printed = false;
  if (input.print && input.printerIp) {
    try {
      await printReceipt(input.printerIp, receiptText);
      printed = true;
    } catch {
      // In reconstruction test mode the receipt remains previewable even though native printing is blocked.
      printed = false;
    }
  }

  return { success, finalDraft, receiptText, refreshedStock, printed };
}
