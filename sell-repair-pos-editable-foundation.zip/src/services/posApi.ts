import { BACKEND } from '../config/backend';
import type { Product } from '../domain/product';
import type { Category, CaseSeries, CaseType, StockRecord, StoreInfo } from '../domain/catalog';
import { demoProducts } from '../data/demoProducts';
import { RECOVERED_ROUTES } from './recoveredRoutes';
import { safeGet } from './http';
import { buildVariantStockQuery, type VariantStockQuery } from './stockQuery';
import { getSession } from './session';
import {
  normalizeProducts,
  normalizeCategories,
  normalizeCaseSeries,
  normalizeCaseTypes,
  normalizeStock,
  normalizeStore,
} from './normalizers';

export type ProductSearch = {
  query?: string;
  category?: string;
};

function filterLocal(products: Product[], search: ProductSearch): Product[] {
  const q = (search.query ?? '').toLowerCase();
  const category = (search.category ?? '').toLowerCase();
  return products.filter(product => {
    const queryOk = !q || `${product.name} ${product.model ?? ''}`.toLowerCase().includes(q);
    const categoryOk = !category || (product.category ?? '').toLowerCase().includes(category);
    return queryOk && categoryOk;
  });
}

export async function searchProducts(search: ProductSearch): Promise<Product[]> {
  if (!BACKEND.liveReadsEnabled) return filterLocal(demoProducts, search);
  const raw = await safeGet<unknown>(RECOVERED_ROUTES.products);
  return filterLocal(normalizeProducts(raw), search);
}

export async function getCategories(): Promise<Category[]> {
  if (!BACKEND.liveReadsEnabled) return [];
  return normalizeCategories(await safeGet<unknown>(RECOVERED_ROUTES.categories));
}

export async function getCaseSeries(): Promise<CaseSeries[]> {
  if (!BACKEND.liveReadsEnabled) return [];
  return normalizeCaseSeries(await safeGet<unknown>(RECOVERED_ROUTES.caseSeries));
}

export async function getCaseTypes(): Promise<CaseType[]> {
  if (!BACKEND.liveReadsEnabled) return [];
  return normalizeCaseTypes(await safeGet<unknown>(RECOVERED_ROUTES.caseTypes));
}

export async function getCurrentStore(): Promise<StoreInfo | null> {
  if (!BACKEND.liveReadsEnabled) return null;
  const storeId = getSession()?.storeId;
  if (storeId === undefined || storeId === null || String(storeId).trim() === '') return null;
  const raw = await safeGet<unknown>(`${RECOVERED_ROUTES.storeByIdPrefix}${encodeURIComponent(String(storeId))}`);
  return normalizeStore(raw);
}

export async function getProductVariants(productId: string, storeId?: string | number): Promise<StockRecord[]> {
  if (!BACKEND.liveReadsEnabled || !productId) return [];
  // The production APK's get_variant_stocks thunk calls
  // ProductStocks/variant-stocks?productId=<id>. Store/variant filters are
  // appended by other stock flows when present.
  return getVariantStocks({ productId, storeId });
}

export async function getVariantStocks(input: VariantStockQuery): Promise<StockRecord[]> {
  if (!BACKEND.liveReadsEnabled) return [];
  const query = buildVariantStockQuery(input);
  if (!query) throw new Error('A store, product or variant ID is required for a stock lookup.');
  const route = `${RECOVERED_ROUTES.variantStocks}${query}`;
  return normalizeStock(await safeGet<unknown>(route));
}

export async function loadCatalogReadOnly(): Promise<{
  products: Product[];
  categories: Category[];
  caseSeries: CaseSeries[];
  caseTypes: CaseType[];
  store: StoreInfo | null;
}> {
  if (!BACKEND.liveReadsEnabled) {
    return { products: demoProducts, categories: [], caseSeries: [], caseTypes: [], store: null };
  }

  const settled = await Promise.allSettled([
    searchProducts({}),
    getCategories(),
    getCaseSeries(),
    getCaseTypes(),
    getCurrentStore(),
  ]);

  return {
    products: settled[0].status === 'fulfilled' ? settled[0].value : [],
    categories: settled[1].status === 'fulfilled' ? settled[1].value : [],
    caseSeries: settled[2].status === 'fulfilled' ? settled[2].value : [],
    caseTypes: settled[3].status === 'fulfilled' ? settled[3].value : [],
    store: settled[4].status === 'fulfilled' ? settled[4].value : null,
  };
}

export async function probeRecoveredRead(path: string): Promise<unknown> {
  return safeGet<unknown>(path);
}
