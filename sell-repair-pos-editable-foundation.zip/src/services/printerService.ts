import { NativeModules } from 'react-native';
import { BACKEND } from '../config/backend';

const EpsonNetworkPrinterModule = NativeModules.EpsonNetworkPrinterModule as undefined | {
  printText?: (printerIp: string, text: string) => Promise<unknown>;
};

export async function printReceipt(printerIp: string, text: string): Promise<unknown> {
  if (!BACKEND.liveWritesEnabled) {
    throw new Error('Printing is disabled in reconstruction safety mode. Receipt preview is available.');
  }
  if (!printerIp.trim()) throw new Error('Printer IP is required');
  if (!EpsonNetworkPrinterModule?.printText) {
    throw new Error('EpsonNetworkPrinterModule.printText is not available in this editable build yet.');
  }
  return EpsonNetworkPrinterModule.printText(printerIp.trim(), text);
}
