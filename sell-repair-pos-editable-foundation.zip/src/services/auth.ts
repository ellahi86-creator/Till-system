import { BACKEND } from '../config/backend';
import { extractStoreId, setSession, type PosSession, type PosUser } from './session';

export const AUTH_ROUTE = 'account/Login';

export type LoginCredentials = {
  email: string;
  password: string;
};

type ProductionLoginData = {
  access_token?: unknown;
  refresh_token?: unknown;
  user?: unknown;
};

type ProductionLoginEnvelope = {
  data?: ProductionLoginData;
  message?: unknown;
};

function asObject(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === 'object' ? (value as Record<string, unknown>) : null;
}

function parseLoginEnvelope(payload: unknown): ProductionLoginData {
  const root = asObject(payload);
  if (!root) throw new Error('Login response was not a JSON object.');

  // Axios returns response.data to the calling code in the original app. The
  // network payload itself may therefore be either the token object directly
  // or an API envelope with a `data` property. Accept both shapes safely.
  const nested = asObject(root.data);
  return (nested ?? root) as ProductionLoginData;
}

export function sessionFromLoginPayload(payload: unknown, username?: string): PosSession {
  const data = parseLoginEnvelope(payload);
  const accessToken = typeof data.access_token === 'string' ? data.access_token : '';

  if (!accessToken) {
    const envelope = asObject(payload) as ProductionLoginEnvelope | null;
    const message = typeof envelope?.message === 'string' ? envelope.message : 'Login succeeded but no access token was returned.';
    throw new Error(message);
  }

  const refreshToken = typeof data.refresh_token === 'string' ? data.refresh_token : undefined;
  const user = asObject(data.user) as PosUser | null;

  return {
    accessToken,
    refreshToken,
    user: user ?? undefined,
    storeId: extractStoreId(user ?? undefined),
    username,
  };
}

export async function login(credentials: LoginCredentials): Promise<PosSession> {
  if (!BACKEND.liveAuthEnabled) {
    throw new Error('Production login is disabled in this build.');
  }

  const email = credentials.email.trim();
  if (!email) throw new Error('Email is required');
  if (!credentials.password) throw new Error('Password is required');

  const response = await fetch(`${BACKEND.baseUrl.replace(/\/$/, '')}/${AUTH_ROUTE}`, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password: credentials.password }),
  });

  let payload: unknown;
  const text = await response.text();
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { message: text || `Login failed (${response.status})` };
  }

  if (!response.ok) {
    const obj = asObject(payload);
    const message =
      (typeof obj?.message === 'string' && obj.message) ||
      (typeof obj?.error === 'string' && obj.error) ||
      `Login failed (${response.status})`;
    throw new Error(message);
  }

  const session = sessionFromLoginPayload(payload, email);
  setSession(session);
  return session;
}
