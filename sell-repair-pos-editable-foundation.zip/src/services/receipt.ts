import type { CheckoutDraft } from '../domain/checkout';

function line(label: string, amount: number): string {
  return `${label} £${amount.toFixed(2)}`;
}

export function buildReceiptText(draft: CheckoutDraft, options?: { vatNumber?: string; date?: Date }): string {
  const date = options?.date ?? new Date();
  const rows = [
    draft.orderNumber ? `Order Number: ${draft.orderNumber}` : 'Order Number: PENDING',
    draft.placedBy ? `Placed By: ${draft.placedBy}` : undefined,
    `Date: ${date.toLocaleString('en-GB')}`,
    options?.vatNumber ? `VAT Number: ${options.vatNumber}` : undefined,
    '',
    'ITEMS',
    ...draft.lines.map(item => `${item.quantity} x ${item.product.name}  £${(item.quantity * item.product.price).toFixed(2)}`),
    '',
    line('Sub Total:', draft.subtotal),
    `Discount(${draft.discountPercent}%): £${draft.discountAmount.toFixed(2)}`,
    line('TOTAL:', draft.total),
    line('Card Amount:', draft.cardAmount),
    line('Cash Amount:', draft.cashAmount),
    `Payment Method: ${draft.paymentMethod}`,
    line('Tendered Amount:', draft.tenderedAmount),
    line('Change Due:', draft.changeDue),
    '',
    draft.receiptNotes,
    '',
    'THANK YOU!',
    '',
    '',
  ];
  return rows.filter((value): value is string => value !== undefined).join('\n');
}
