/**
 * Routes/operation names recovered from the current production APK.
 * They are intentionally NOT executed automatically.
 */
export const RECOVERED_ROUTES = {
  stores: 'get_all_stores?pageNumber=1&pageSize=1000',
  createOrder: 'orders/',
  orderList: 'orders?',
  orderDetailsByNumber: 'orders/details?number=',
  storeByIdPrefix: 'stores/',
  suppliers: 'get_all_suppliers',
  supplierLookup: 'lookup_suppliers?',
  products: 'get_all_products',
  createBulkCases: 'CreateBulkCases',
  categories: 'get_all_categories',
  brands: 'get_all_brands',
  caseSeries: 'get_case_series',
  caseTypes: 'get_case_types',
  variantStocks: 'ProductStocks/variant-stocks?',
  variantBatches: 'ProductStocks/batches-with-variant?',
  productStockLogs: 'ProductStocks/logs?',
  addProductStockCase: 'ProductStocks/add-case',
  purchases: 'get_all_purchases',
  purchaseTransfers: 'Purchases/TransferLogs?',
  transactions: 'get_all_transactions',
  salesDashboard: 'reports/dashboard?storeId=',
  weeklySales: 'Reports/WeeklySales?storeId=',
  singleDaySales: 'get_reports/SingleDaySales?date=',
  salesExcel: 'Reports/SalesExcel?fromDate=',
  productExport: 'Products/Export?platform=',
  transactionExport: 'Transactions/Export?startDate=',
} as const;
