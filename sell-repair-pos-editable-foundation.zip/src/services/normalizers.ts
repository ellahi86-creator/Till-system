import type { Product } from '../domain/product';
import type { Category, CaseSeries, CaseType, StockRecord, StoreInfo } from '../domain/catalog';

function asObject(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function firstArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  const root = asObject(value);
  if (!root) return [];

  const directKeys = ['data', 'items', 'results', 'result', 'records', 'products', 'categories', 'caseSeries', 'case_series', 'caseTypes', 'case_types', 'stocks', 'variants'];
  for (const key of directKeys) {
    const candidate = root[key];
    if (Array.isArray(candidate)) return candidate;
    const nested = asObject(candidate);
    if (nested) {
      for (const nestedKey of ['items', 'results', 'result', 'records', 'data']) {
        if (Array.isArray(nested[nestedKey])) return nested[nestedKey] as unknown[];
      }
    }
  }

  for (const candidate of Object.values(root)) {
    if (Array.isArray(candidate)) return candidate;
  }
  return [];
}

function text(obj: Record<string, unknown>, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = obj[key];
    if (typeof value === 'string' && value.trim()) return value.trim();
    if (typeof value === 'number') return String(value);
  }
  return undefined;
}

function numberValue(obj: Record<string, unknown>, keys: string[]): number | undefined {
  for (const key of keys) {
    const value = obj[key];
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string' && value.trim() && Number.isFinite(Number(value))) return Number(value);
  }
  return undefined;
}

function entityName(obj: Record<string, unknown>): string | undefined {
  return text(obj, ['name', 'title', 'product_name', 'productName', 'category_name', 'categoryName', 'series_name', 'seriesName', 'type_name', 'typeName']);
}

function nestedName(obj: Record<string, unknown>, keys: string[]): string | undefined {
  for (const key of keys) {
    const nested = asObject(obj[key]);
    if (!nested) continue;
    const name = entityName(nested);
    if (name) return name;
  }
  return undefined;
}

function unwrapObject(payload: unknown): Record<string, unknown> | null {
  let current = asObject(payload);
  for (let i = 0; i < 3 && current; i += 1) {
    const next = asObject(current.data) ?? asObject(current.result);
    if (!next) return current;
    current = next;
  }
  return current;
}

export function normalizeProducts(payload: unknown): Product[] {
  return firstArray(payload).flatMap((entry, index) => {
    const obj = asObject(entry);
    if (!obj) return [];

    const name = entityName(obj);
    if (!name) return [];

    const id = text(obj, ['id', 'product_id', 'productId', 'uuid']) ?? `recovered-${index}-${name}`;
    const price = numberValue(obj, ['selling_price', 'sellingPrice', 'sellPrice', 'sale_price', 'salePrice', 'retail_price', 'retailPrice', 'price']) ?? 0;
    const category = text(obj, ['category', 'category_name', 'categoryName']) ?? nestedName(obj, ['category']);
    const subcategory = text(obj, ['subcategory', 'sub_category', 'subCategory', 'subcategory_name', 'subcategoryName']) ?? nestedName(obj, ['subcategory', 'sub_category']);
    const model = text(obj, ['model', 'model_name', 'modelName', 'modelNumber', 'device_model', 'deviceModel']);
    const sku = text(obj, ['sku', 'product_code', 'productCode', 'barcode']);

    return [{ id, name, sku, category, subcategory, model, price, raw: obj } as Product];
  });
}

function normalizeNamed<T extends Category | CaseSeries | CaseType>(payload: unknown): T[] {
  return firstArray(payload).flatMap((entry, index) => {
    const obj = asObject(entry);
    if (!obj) return [];
    const name = entityName(obj);
    if (!name) return [];
    const id = text(obj, ['id', 'category_id', 'categoryId', 'case_series_id', 'caseSeriesId', 'case_type_id', 'caseTypeId', 'uuid']) ?? `recovered-${index}-${name}`;
    return [{ id, name } as T];
  });
}

export const normalizeCategories = (payload: unknown) => normalizeNamed<Category>(payload);
export const normalizeCaseSeries = (payload: unknown) => normalizeNamed<CaseSeries>(payload);
export const normalizeCaseTypes = (payload: unknown) => normalizeNamed<CaseType>(payload);

export function normalizeStock(payload: unknown): StockRecord[] {
  return firstArray(payload).flatMap(entry => {
    const obj = asObject(entry);
    if (!obj) return [];
    const totalStock = numberValue(obj, ['totalStock', 'total_stock', 'stock', 'available_stock', 'availableStock', 'quantity', 'qty']);
    return [{
      id: text(obj, ['id']),
      productId: text(obj, ['product_id', 'productId']),
      variantId: text(obj, ['variant_id', 'variantId', 'id']),
      name: text(obj, ['name']),
      modelName: text(obj, ['modelName', 'model_name']),
      modelNumber: text(obj, ['modelNumber', 'model_number']),
      colorName: text(obj, ['colorName', 'color_name', 'color']),
      quantity: numberValue(obj, ['quantity', 'qty']),
      totalStock,
      storeId: text(obj, ['store_id', 'storeId', 'StoreId']),
      raw: obj,
    }];
  });
}

export function normalizeStore(payload: unknown): StoreInfo | null {
  const obj = unwrapObject(payload);
  if (!obj) return null;
  const id = text(obj, ['id', 'storeId', 'store_id', 'StoreId']);
  if (!id) return null;
  return {
    id,
    name: text(obj, ['name', 'storeName', 'store_name']),
    address: text(obj, ['address', 'storeAddress', 'store_address']),
    simpleAddress: text(obj, ['simpleAddress', 'storeSimpleAddress', 'store_simple_address']),
    raw: obj,
  };
}
