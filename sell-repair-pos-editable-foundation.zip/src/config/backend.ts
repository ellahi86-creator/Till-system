export const BACKEND = {
  // Recovered from the current APK: API_BASE_URL = IP + '/api/v1'
  baseUrl: 'https://api.sellandrepair.co.uk/api/v1',
  // Login and catalogue reads may use the production API.
  liveAuthEnabled: true,
  liveReadsEnabled: true,
  // Hard safety switch: never create real orders or change live stock in this test build.
  liveWritesEnabled: false,
  // UI test mode allows checkout to complete locally without sending a production sale.
  testMode: true,
} as const;
