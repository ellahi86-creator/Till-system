import type { Product } from '../domain/product';

export const demoProducts: Product[] = [
  { id: 'case-iphone-16', name: 'iPhone 16 Clear Case', category: 'Cases', model: 'iPhone 16', price: 14.99 },
  { id: 'sp-iphone-16', name: 'iPhone 16 Tempered Glass Screen Protector', category: 'Screen Protectors', model: 'iPhone 16', price: 9.99 },
  { id: 'cable-usbc', name: 'USB-C Cable 1m', category: 'Cables', price: 8.99 },
];
