export type Category = {
  id: string;
  name: string;
};

export type CaseSeries = {
  id: string;
  name: string;
};

export type CaseType = {
  id: string;
  name: string;
};

export type StoreInfo = {
  id: string;
  name?: string;
  address?: string;
  simpleAddress?: string;
  raw: Record<string, unknown>;
};

export type StockRecord = {
  id?: string;
  productId?: string;
  variantId?: string;
  name?: string;
  modelName?: string;
  modelNumber?: string;
  colorName?: string;
  quantity?: number;
  totalStock?: number;
  storeId?: string;
  raw: Record<string, unknown>;
};
