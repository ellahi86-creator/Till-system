import type { CartLine, Product } from './product';

const normalize = (value?: string) => (value ?? '').trim().toLowerCase();

const CASE_TERMS = [
  'case',
  'cases',
  'phone case',
  'mobile case',
  'cover',
  'covers',
  'phone cover',
  'mobile cover',
];

const PROTECTOR_TERMS = [
  'screen protector',
  'screen protectors',
  'tempered glass',
  'tempered',
  'glass protector',
];

const containsAny = (value: string, terms: string[]) =>
  terms.some(term => value === term || value.includes(term));

export function isPhoneCase(product: Product): boolean {
  const fields = [product.category, product.subcategory, product.name]
    .map(normalize)
    .filter(Boolean);

  return fields.some(value => containsAny(value, CASE_TERMS));
}

export function isScreenProtector(product: Product): boolean {
  const fields = [product.category, product.subcategory, product.name]
    .map(normalize)
    .filter(Boolean);

  return fields.some(value => containsAny(value, PROTECTOR_TERMS));
}

export function cartHasScreenProtector(cart: CartLine[]): boolean {
  return cart.some(line => isScreenProtector(line.product));
}

export function shouldPromptScreenProtector(
  selectedProduct: Product,
  cartBeforeAdd: CartLine[],
): boolean {
  return isPhoneCase(selectedProduct) && !cartHasScreenProtector(cartBeforeAdd);
}

export function modelSearchHint(product: Product): string {
  return (product.model || product.name)
    .replace(/\b(case|cover|phone case|mobile case)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
}
