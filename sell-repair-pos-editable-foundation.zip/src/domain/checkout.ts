import type { CartLine } from './product';

export type PaymentMethod = 'Cash' | 'Card' | 'Split';

export type CheckoutDraft = {
  storeId?: string | number;
  placedBy?: string;
  orderNumber?: string;
  lines: CartLine[];
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  total: number;
  cashAmount: number;
  cardAmount: number;
  tenderedAmount: number;
  changeDue: number;
  paymentMethod: PaymentMethod;
  receiptNotes: string;
  status: string;
};

export function money(value: number): number {
  return Math.round((Number.isFinite(value) ? value : 0) * 100) / 100;
}

export function buildCheckoutDraft(input: {
  lines: CartLine[];
  discountPercent?: number;
  cashAmount?: number;
  cardAmount?: number;
  storeId?: string | number;
  placedBy?: string;
  orderNumber?: string;
  receiptNotes?: string;
  status?: string;
}): CheckoutDraft {
  const subtotal = money(input.lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0));
  const discountPercent = Math.min(100, Math.max(0, Number(input.discountPercent) || 0));
  const discountAmount = money(subtotal * discountPercent / 100);
  const total = money(Math.max(0, subtotal - discountAmount));
  const cashAmount = money(Math.max(0, Number(input.cashAmount) || 0));
  const cardAmount = money(Math.max(0, Number(input.cardAmount) || 0));
  const tenderedAmount = money(cashAmount + cardAmount);
  const changeDue = money(Math.max(0, tenderedAmount - total));
  const paymentMethod: PaymentMethod = cashAmount > 0 && cardAmount > 0 ? 'Split' : cardAmount > 0 ? 'Card' : 'Cash';

  return {
    storeId: input.storeId,
    placedBy: input.placedBy,
    orderNumber: input.orderNumber,
    lines: input.lines,
    subtotal,
    discountPercent,
    discountAmount,
    total,
    cashAmount,
    cardAmount,
    tenderedAmount,
    changeDue,
    paymentMethod,
    receiptNotes: input.receiptNotes ?? 'Generated via POS',
    status: input.status ?? 'completed',
  };
}

export function checkoutIsPayable(draft: CheckoutDraft): boolean {
  return draft.lines.length > 0 && draft.tenderedAmount >= draft.total;
}
