export type Product = {
  id: string;
  name: string;
  sku?: string;
  category?: string;
  subcategory?: string;
  model?: string;
  price: number;
  raw?: Record<string, unknown>;
};

export type CartLine = {
  product: Product;
  quantity: number;
  variantId?: string;
  variantLabel?: string;
};
