import React, { useMemo, useState } from 'react';
import { Modal, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import type { CartLine } from '../domain/product';
import type { StockRecord } from '../domain/catalog';
import { buildCheckoutDraft, checkoutIsPayable } from '../domain/checkout';
import { buildReceiptText } from '../services/receipt';
import { getSession } from '../services/session';
import { buildRecoveredOrderPayload, submitOrderSafely } from '../services/orderService';
import { runPostSaleFlow } from '../services/postSale';
import { BACKEND } from '../config/backend';

export function CheckoutModal(props: {
  visible: boolean;
  lines: CartLine[];
  onClose: () => void;
  onCompleted?: (result: {
    orderNumber?: string;
    refreshedStock: Record<string, StockRecord[]>;
  }) => void;
  printerIp?: string;
}) {
  const [discount, setDiscount] = useState('0');
  const [cash, setCash] = useState('0');
  const [card, setCard] = useState('0');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const draft = useMemo(() => buildCheckoutDraft({
    lines: props.lines,
    discountPercent: Number(discount),
    cashAmount: Number(cash),
    cardAmount: Number(card),
    storeId: getSession()?.storeId,
    placedBy: getSession()?.user?.name as string | undefined,
  }), [props.lines, discount, cash, card]);

  const receipt = useMemo(() => buildReceiptText(draft), [draft]);
  const payload = useMemo(() => buildRecoveredOrderPayload(draft), [draft]);

  const fillCash = () => {
    setCash(String(draft.total.toFixed(2)));
    setCard('0');
  };

  const fillCard = () => {
    setCard(String(draft.total.toFixed(2)));
    setCash('0');
  };

  const trySubmit = async () => {
    setMessage('');
    setSubmitting(true);
    try {
      const success = await submitOrderSafely(draft);
      const postSale = await runPostSaleFlow({
        draft,
        responseBody: success.raw,
        printerIp: props.printerIp,
        print: Boolean(props.printerIp),
      });
      props.onCompleted?.({
        orderNumber: postSale.success.orderNumber,
        refreshedStock: postSale.refreshedStock,
      });
      setMessage(postSale.success.orderNumber
        ? `Order ${postSale.success.orderNumber} completed.`
        : 'Order completed.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Sale submission is blocked.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal visible={props.visible} transparent animationType="fade" onRequestClose={props.onClose}>
      <View style={styles.backdrop}>
        <View style={styles.card}>
          <View style={styles.header}>
            <Text style={styles.title}>Checkout</Text>
            <Pressable onPress={props.onClose}><Text style={styles.close}>Close</Text></Pressable>
          </View>

          <View style={styles.columns}>
            <View style={styles.left}>
              <Text style={styles.label}>Discount (%)</Text>
              <TextInput keyboardType="decimal-pad" value={discount} onChangeText={setDiscount} style={styles.input} />

              <Text style={styles.summary}>Subtotal: £{draft.subtotal.toFixed(2)}</Text>
              <Text style={styles.summary}>Discount: £{draft.discountAmount.toFixed(2)}</Text>
              <Text style={styles.total}>Total: £{draft.total.toFixed(2)}</Text>

              <View style={styles.quickRow}>
                <Pressable style={styles.quickButton} onPress={fillCash}><Text style={styles.quickText}>Cash</Text></Pressable>
                <Pressable style={styles.quickButton} onPress={fillCard}><Text style={styles.quickText}>Card</Text></Pressable>
              </View>

              <Text style={styles.label}>Cash Amount</Text>
              <TextInput keyboardType="decimal-pad" value={cash} onChangeText={setCash} style={styles.input} />
              <Text style={styles.label}>Card Amount</Text>
              <TextInput keyboardType="decimal-pad" value={card} onChangeText={setCard} style={styles.input} />

              <Text style={styles.summary}>Payment: {draft.paymentMethod}</Text>
              <Text style={styles.summary}>Tendered: £{draft.tenderedAmount.toFixed(2)}</Text>
              <Text style={styles.summary}>Change Due: £{draft.changeDue.toFixed(2)}</Text>

              <Pressable
                style={[styles.confirm, (!checkoutIsPayable(draft) || submitting) && styles.confirmDisabled]}
                onPress={trySubmit}
                disabled={!checkoutIsPayable(draft) || submitting}
              >
                <Text style={styles.confirmText}>{submitting ? 'Processing…' : 'Confirm Order'}</Text>
              </Pressable>
              <Text style={styles.safety}>{BACKEND.testMode ? 'TEST MODE: Confirm Order completes locally only. No production sale or stock write is sent.' : 'Production sale writes and printing are intentionally blocked until controlled live testing.'}</Text>
              {!!message && <Text style={styles.message}>{message}</Text>}
            </View>

            <View style={styles.right}>
              <Text style={styles.previewTitle}>Receipt Preview</Text>
              <ScrollView style={styles.receipt}><Text style={styles.receiptText}>{receipt}</Text></ScrollView>
              <Text style={styles.previewTitle}>Recovered Payload Preview</Text>
              <ScrollView style={styles.payload}><Text style={styles.payloadText}>{JSON.stringify(payload, null, 2)}</Text></ScrollView>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center', padding: 24 },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 18, maxHeight: '92%' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  title: { fontSize: 26, fontWeight: '900' },
  close: { fontWeight: '800', textDecorationLine: 'underline' },
  columns: { flexDirection: 'row', gap: 18, minHeight: 520 },
  left: { flex: 0.9 },
  right: { flex: 1.1 },
  label: { fontSize: 12, fontWeight: '800', marginTop: 9, marginBottom: 4 },
  input: { borderWidth: 1, borderColor: '#bbb', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 9, backgroundColor: '#fff' },
  summary: { fontSize: 15, marginTop: 8 },
  total: { fontSize: 23, fontWeight: '900', marginTop: 10 },
  quickRow: { flexDirection: 'row', gap: 8, marginTop: 12 },
  quickButton: { flex: 1, borderWidth: 1, borderColor: '#aaa', borderRadius: 9, padding: 12, alignItems: 'center' },
  quickText: { fontWeight: '900' },
  confirm: { marginTop: 18, padding: 14, borderRadius: 10, backgroundColor: '#111', alignItems: 'center' },
  confirmDisabled: { opacity: 0.35 },
  confirmText: { color: '#fff', fontWeight: '900' },
  safety: { fontSize: 11, marginTop: 7, fontWeight: '700' },
  message: { marginTop: 8, fontSize: 12, fontWeight: '700' },
  previewTitle: { fontSize: 14, fontWeight: '900', marginBottom: 6 },
  receipt: { flex: 1, borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 10, backgroundColor: '#fafafa' },
  receiptText: { fontFamily: 'monospace', fontSize: 12 },
  payload: { flex: 0.7, borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 10, marginTop: 6 },
  payloadText: { fontFamily: 'monospace', fontSize: 10 },
});
