import React from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';

export type ScreenProtectorUpsellModalProps = {
  visible: boolean;
  onAddProtector: () => void;
  onNoThanks: () => void;
};

export function ScreenProtectorUpsellModal({
  visible,
  onAddProtector,
  onNoThanks,
}: ScreenProtectorUpsellModalProps) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onNoThanks}>
      <View style={styles.backdrop}>
        <View style={styles.card}>
          <Text style={styles.title}>Screen Protector</Text>
          <Text style={styles.message}>Ask the customer if they would like a screen protector.</Text>

          <Pressable style={styles.primaryButton} onPress={onAddProtector}>
            <Text style={styles.primaryText}>Add Screen Protector</Text>
          </Pressable>
          <Pressable style={styles.secondaryButton} onPress={onNoThanks}>
            <Text style={styles.secondaryText}>No Thanks</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    width: '100%',
    maxWidth: 480,
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
  },
  title: { fontSize: 24, fontWeight: '800', marginBottom: 10 },
  message: { fontSize: 18, lineHeight: 26, marginBottom: 24 },
  primaryButton: { backgroundColor: '#111', padding: 16, borderRadius: 10, marginBottom: 10 },
  primaryText: { color: '#fff', textAlign: 'center', fontSize: 17, fontWeight: '700' },
  secondaryButton: { borderWidth: 1, borderColor: '#aaa', padding: 16, borderRadius: 10 },
  secondaryText: { textAlign: 'center', fontSize: 17, fontWeight: '600' },
});
