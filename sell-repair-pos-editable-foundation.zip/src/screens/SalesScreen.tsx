import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenProtectorUpsellModal } from '../components/ScreenProtectorUpsellModal';
import { CheckoutModal } from '../components/CheckoutModal';
import type { CartLine, Product } from '../domain/product';
import type { Category, StockRecord, StoreInfo } from '../domain/catalog';
import { modelSearchHint, shouldPromptScreenProtector } from '../domain/upsell';
import { getProductVariants, loadCatalogReadOnly } from '../services/posApi';
import { getSession } from '../services/session';
import { BACKEND } from '../config/backend';

function addLine(cart: CartLine[], product: Product): CartLine[] {
  const index = cart.findIndex(line => line.product.id === product.id);
  if (index === -1) return [...cart, { product, quantity: 1 }];

  return cart.map((line, i) =>
    i === index ? { ...line, quantity: line.quantity + 1 } : line,
  );
}

function stockTotal(rows: StockRecord[]): number | undefined {
  if (!rows.length) return undefined;
  const values = rows
    .map(row => row.totalStock ?? row.quantity)
    .filter((value): value is number => typeof value === 'number' && Number.isFinite(value));
  if (!values.length) return undefined;
  return values.reduce((sum, value) => sum + value, 0);
}

function variantLabel(row: StockRecord): string {
  return [row.name, row.modelName, row.modelNumber, row.colorName]
    .filter(Boolean)
    .join(' • ') || row.variantId || 'Variant';
}

export function SalesScreen() {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [upsellVisible, setUpsellVisible] = useState(false);
  const [caseProduct, setCaseProduct] = useState<Product | null>(null);
  const [protectorMode, setProtectorMode] = useState(false);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [store, setStore] = useState<StoreInfo | null>(null);
  const [stockByProduct, setStockByProduct] = useState<Record<string, StockRecord[]>>({});
  const [stockLoading, setStockLoading] = useState<Record<string, boolean>>({});
  const [selectedStockProductId, setSelectedStockProductId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [checkoutVisible, setCheckoutVisible] = useState(false);
  const [printerIp, setPrinterIp] = useState('');

  const reloadCatalog = () => {
    setLoading(true);
    setLoadError('');
    loadCatalogReadOnly()
      .then(catalog => {
        setAllProducts(catalog.products);
        setCategories(catalog.categories);
        setStore(catalog.store);
        if (!catalog.products.length) {
          setLoadError('Connected, but no products could be mapped from the recovered endpoint yet.');
        }
      })
      .catch(error => {
        setLoadError(error instanceof Error ? error.message : 'Could not load the POS catalogue.');
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    reloadCatalog();
  }, []);

  const products = useMemo(() => {
    const q = query.trim().toLowerCase();
    const category = selectedCategory.trim().toLowerCase();
    return allProducts.filter(product => {
      const matchesQuery = !q || `${product.name} ${product.model ?? ''} ${product.sku ?? ''}`.toLowerCase().includes(q);
      const matchesCategory = !category || (product.category ?? '').toLowerCase() === category;
      const matchesProtector = !protectorMode || (product.category ?? '').toLowerCase().includes('screen protector');
      return matchesQuery && matchesCategory && matchesProtector;
    });
  }, [allProducts, query, selectedCategory, protectorMode]);

  const loadStockForProduct = async (product: Product, focus = false) => {
    if (stockLoading[product.id]) return;
    if (focus) setSelectedStockProductId(product.id);
    if (stockByProduct[product.id]) return;

    setStockLoading(current => ({ ...current, [product.id]: true }));
    try {
      const rows = await getProductVariants(product.id, getSession()?.storeId);
      setStockByProduct(current => ({ ...current, [product.id]: rows }));
    } catch {
      setStockByProduct(current => ({ ...current, [product.id]: [] }));
    } finally {
      setStockLoading(current => ({ ...current, [product.id]: false }));
    }
  };

  const selectProduct = (product: Product) => {
    const prompt = shouldPromptScreenProtector(product, cart);
    const rows = stockByProduct[product.id] ?? [];
    if (rows.length > 1) {
      setSelectedStockProductId(product.id);
      void loadStockForProduct(product, true);
      return;
    }
    const only = rows.length === 1 ? rows[0] : undefined;
    setCart(current => {
      const existing = current.find(line => line.product.id === product.id && line.variantId === only?.variantId);
      if (!existing) return [...current, { product, quantity: 1, variantId: only?.variantId, variantLabel: only ? variantLabel(only) : undefined }];
      return current.map(line => line === existing ? { ...line, quantity: line.quantity + 1 } : line);
    });
    void loadStockForProduct(product);

    if (prompt) {
      setCaseProduct(product);
      setUpsellVisible(true);
    }
  };

  const selectVariant = (product: Product, row: StockRecord) => {
    const prompt = shouldPromptScreenProtector(product, cart);
    setCart(current => {
      const existing = current.find(line => line.product.id === product.id && line.variantId === row.variantId);
      if (!existing) return [...current, { product, quantity: 1, variantId: row.variantId, variantLabel: variantLabel(row) }];
      return current.map(line => line === existing ? { ...line, quantity: line.quantity + 1 } : line);
    });
    if (prompt) {
      setCaseProduct(product);
      setUpsellVisible(true);
    }
  };

  const showCompatibleProtectors = () => {
    setUpsellVisible(false);
    setProtectorMode(true);
    setSelectedCategory('');
    setQuery(caseProduct ? modelSearchHint(caseProduct) : '');
  };

  const total = cart.reduce((sum, line) => sum + line.product.price * line.quantity, 0);
  const selectedStock = selectedStockProductId ? stockByProduct[selectedStockProductId] ?? [] : [];
  const selectedStockProduct = allProducts.find(product => product.id === selectedStockProductId);

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.topRow}>
        <View>
          <Text style={styles.heading}>Sell & Repair POS</Text>
          <Text style={styles.storeText}>{store?.name ?? (getSession()?.storeId ? `Store ${getSession()?.storeId}` : 'Store not resolved')}</Text>
        </View>
        <Text style={styles.readOnly}>{BACKEND.testMode ? 'TEST MODE • LIVE CATALOGUE • NO REAL SALES' : 'LIVE CATALOGUE + STOCK • WRITES BLOCKED'}</Text>
      </View>

      <View style={styles.testControls}>
        <Text style={styles.testLabel}>Epson printer IP (optional test setting)</Text>
        <TextInput
          value={printerIp}
          onChangeText={setPrinterIp}
          placeholder="e.g. 192.168.1.50"
          autoCapitalize="none"
          keyboardType="numbers-and-punctuation"
          style={styles.printerInput}
        />
      </View>

      <TextInput
        value={query}
        onChangeText={setQuery}
        placeholder={protectorMode ? 'Compatible screen protectors' : 'Search name, model or SKU'}
        style={styles.search}
      />

      {!!categories.length && !protectorMode && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryStrip}>
          <Pressable style={[styles.categoryChip, !selectedCategory && styles.categoryChipActive]} onPress={() => setSelectedCategory('')}>
            <Text>All</Text>
          </Pressable>
          {categories.map(category => (
            <Pressable
              key={category.id}
              style={[styles.categoryChip, selectedCategory === category.name && styles.categoryChipActive]}
              onPress={() => setSelectedCategory(category.name)}
            >
              <Text>{category.name}</Text>
            </Pressable>
          ))}
        </ScrollView>
      )}

      {protectorMode && (
        <Pressable onPress={() => { setProtectorMode(false); setQuery(''); }}>
          <Text style={styles.clearFilter}>Show all products</Text>
        </Pressable>
      )}

      {!!loadError && (
        <View style={styles.errorBox}>
          <Text style={styles.errorText}>{loadError}</Text>
          <Pressable onPress={reloadCatalog}><Text style={styles.retry}>Retry catalogue</Text></Pressable>
        </View>
      )}

      <View style={styles.columns}>
        <View style={styles.productColumn}>
          <Text style={styles.sectionTitle}>{loading ? 'Loading live products…' : `Products (${products.length})`}</Text>
          <FlatList
            data={products}
            keyExtractor={item => item.id}
            renderItem={({ item }) => {
              const stockRows = stockByProduct[item.id];
              const totalStock = stockRows ? stockTotal(stockRows) : undefined;
              return (
                <View style={styles.product}>
                  <Pressable style={styles.productMain} onPress={() => selectProduct(item)}>
                    <View style={styles.productText}>
                      <Text style={styles.productName}>{item.name}</Text>
                      {!!item.sku && <Text style={styles.meta}>{item.sku}</Text>}
                      {!!item.category && <Text style={styles.meta}>{item.category}</Text>}
                      <Text style={styles.stockText}>
                        {stockLoading[item.id]
                          ? 'Checking live stock…'
                          : stockRows
                            ? `Live stock: ${totalStock ?? 'see variants'}`
                            : 'Live stock: not checked'}
                      </Text>
                    </View>
                    <Text>£{item.price.toFixed(2)}</Text>
                  </Pressable>
                  <Pressable style={styles.stockButton} onPress={() => void loadStockForProduct(item, true)}>
                    <Text style={styles.stockButtonText}>View variants</Text>
                  </Pressable>
                </View>
              );
            }}
          />
        </View>

        <View style={styles.cartColumn}>
          <Text style={styles.sectionTitle}>Basket</Text>
          {cart.map((line, index) => (
            <View key={`${line.product.id}:${line.variantId ?? 'base'}:${index}`} style={styles.cartLine}>
              <Text style={styles.cartName}>{line.quantity} × {line.product.name}{line.variantLabel ? `\n${line.variantLabel}` : ''}</Text>
              <Text>£{(line.quantity * line.product.price).toFixed(2)}</Text>
            </View>
          ))}
          <Text style={styles.total}>Total £{total.toFixed(2)}</Text>
          <Pressable style={styles.checkoutButton} onPress={() => setCheckoutVisible(true)} disabled={!cart.length}>
            <Text style={styles.checkoutText}>Checkout</Text>
          </Pressable>

          {!!selectedStockProduct && (
            <View style={styles.variantPanel}>
              <Text style={styles.variantTitle}>Live variants: {selectedStockProduct.name}</Text>
              {stockLoading[selectedStockProduct.id] ? (
                <Text style={styles.meta}>Loading…</Text>
              ) : selectedStock.length ? (
                selectedStock.map((row, index) => (
                  <Pressable key={`${row.variantId ?? row.id ?? index}`} style={styles.variantRow} onPress={() => selectVariant(selectedStockProduct, row)}>
                    <Text style={styles.variantName}>{variantLabel(row)}</Text>
                    <Text style={styles.variantQty}>{row.totalStock ?? row.quantity ?? '—'} • Add</Text>
                  </Pressable>
                ))
              ) : (
                <Text style={styles.meta}>No variant stock returned for this product/store.</Text>
              )}
            </View>
          )}
        </View>
      </View>

      <ScreenProtectorUpsellModal
        visible={upsellVisible}
        onAddProtector={showCompatibleProtectors}
        onNoThanks={() => setUpsellVisible(false)}
      />
      <CheckoutModal
        visible={checkoutVisible}
        lines={cart}
        onClose={() => setCheckoutVisible(false)}
        printerIp={printerIp.trim() || (typeof store?.raw?.printerIp === 'string' ? store.raw.printerIp : undefined)}
        onCompleted={({ refreshedStock }) => {
          setStockByProduct(current => ({ ...current, ...refreshedStock }));
          setCart([]);
          setCheckoutVisible(false);
          setProtectorMode(false);
          setQuery('');
          setSelectedCategory('');
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, padding: 18, backgroundColor: '#f5f5f5' },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  heading: { fontSize: 28, fontWeight: '900' },
  storeText: { fontSize: 13, fontWeight: '700', marginBottom: 14 },
  readOnly: { fontSize: 11, fontWeight: '800' },
  testControls: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  testLabel: { fontSize: 11, fontWeight: '800' },
  printerInput: { minWidth: 190, backgroundColor: '#fff', borderWidth: 1, borderColor: '#ccc', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 8, fontSize: 13 },
  search: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#ccc', padding: 14, borderRadius: 10, fontSize: 17 },
  categoryStrip: { flexGrow: 0, marginTop: 10 },
  categoryChip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 18, backgroundColor: '#fff', marginRight: 8, borderWidth: 1, borderColor: '#ddd' },
  categoryChipActive: { borderWidth: 2 },
  clearFilter: { marginVertical: 10, fontWeight: '700', textDecorationLine: 'underline' },
  errorBox: { marginTop: 10, padding: 12, backgroundColor: '#fff', borderWidth: 1, borderColor: '#bbb', borderRadius: 10 },
  errorText: { fontWeight: '600' },
  retry: { marginTop: 6, fontWeight: '800', textDecorationLine: 'underline' },
  columns: { flex: 1, flexDirection: 'row', gap: 16, marginTop: 16 },
  productColumn: { flex: 1.3, backgroundColor: '#fff', padding: 14, borderRadius: 12 },
  cartColumn: { flex: 1, backgroundColor: '#fff', padding: 14, borderRadius: 12 },
  sectionTitle: { fontSize: 21, fontWeight: '800', marginBottom: 10 },
  product: { paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#bbb' },
  productMain: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  productText: { flex: 1 },
  productName: { fontSize: 16, fontWeight: '600' },
  meta: { fontSize: 12, marginTop: 2 },
  stockText: { fontSize: 12, fontWeight: '700', marginTop: 4 },
  stockButton: { alignSelf: 'flex-start', marginTop: 7, borderWidth: 1, borderColor: '#bbb', borderRadius: 7, paddingHorizontal: 9, paddingVertical: 5 },
  stockButtonText: { fontSize: 12, fontWeight: '800' },
  cartLine: { paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#ddd', flexDirection: 'row', justifyContent: 'space-between', gap: 12 },
  cartName: { flex: 1 },
  total: { fontSize: 22, fontWeight: '900', marginTop: 20 },
  checkoutButton: { marginTop: 12, backgroundColor: '#111', borderRadius: 10, paddingVertical: 13, alignItems: 'center' },
  checkoutText: { color: '#fff', fontWeight: '900', fontSize: 16 },
  variantPanel: { marginTop: 20, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#bbb', paddingTop: 12 },
  variantTitle: { fontSize: 15, fontWeight: '900', marginBottom: 8 },
  variantRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 10, paddingVertical: 5 },
  variantName: { flex: 1, fontSize: 12 },
  variantQty: { fontSize: 13, fontWeight: '900' },
});
