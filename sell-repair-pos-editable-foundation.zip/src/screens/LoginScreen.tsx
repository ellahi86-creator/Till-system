import React, { useState } from 'react';
import { ActivityIndicator, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from 'react-native';
import { login } from '../services/auth';
import type { PosSession } from '../services/session';

type Props = {
  onLogin: (session: PosSession) => void;
  onDemoLogin: () => void;
};

export function LoginScreen({ onLogin, onDemoLogin }: Props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleLogin() {
    if (loading) return;
    setError('');
    setLoading(true);
    try {
      const session = await login({ email, password });
      onLogin(session);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Please check your credentials and try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.card}>
        <Text style={styles.logo}>Sell & Repair POS</Text>
        <Text style={styles.note}>Production login contract reconstructed from the current APK. Stock and sale writes remain disabled.</Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder="Email"
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="email-address"
          style={styles.input}
        />
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="Password"
          secureTextEntry
          style={styles.input}
          onSubmitEditing={handleLogin}
        />
        {!!error && <Text style={styles.error}>{error}</Text>}
        <Pressable style={[styles.loginButton, loading && styles.buttonDisabled]} disabled={loading} onPress={handleLogin}>
          {loading ? <ActivityIndicator /> : <Text style={styles.loginText}>Log in</Text>}
        </Pressable>
        <Pressable style={styles.demoButton} onPress={onDemoLogin} disabled={loading}>
          <Text style={styles.demoText}>Open Safe Demo Till</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, justifyContent: 'center', backgroundColor: '#f5f5f5', padding: 24 },
  card: { alignSelf: 'center', width: '100%', maxWidth: 520, backgroundColor: '#fff', padding: 24, borderRadius: 16 },
  logo: { fontSize: 30, fontWeight: '900', marginBottom: 10 },
  note: { fontSize: 14, lineHeight: 20, marginBottom: 18 },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 10, padding: 14, marginBottom: 12, fontSize: 16 },
  error: { marginBottom: 10, fontSize: 14, fontWeight: '600' },
  loginButton: { backgroundColor: '#111', padding: 14, borderRadius: 10, marginTop: 4, minHeight: 48, justifyContent: 'center' },
  buttonDisabled: { opacity: 0.6 },
  loginText: { color: '#fff', textAlign: 'center', fontWeight: '800' },
  demoButton: { borderWidth: 1, borderColor: '#111', padding: 14, borderRadius: 10, marginTop: 12 },
  demoText: { textAlign: 'center', fontWeight: '800' },
});
