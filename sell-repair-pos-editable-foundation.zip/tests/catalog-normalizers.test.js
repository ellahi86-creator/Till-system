const fs = require('fs');
const path = require('path');

const source = fs.readFileSync(path.join(__dirname, '../src/services/normalizers.ts'), 'utf8');
const required = [
  'normalizeProducts',
  'normalizeCategories',
  'normalizeCaseSeries',
  'normalizeCaseTypes',
  'normalizeStock',
  "['data', 'items', 'results', 'result', 'records'",
];
for (const needle of required) {
  if (!source.includes(needle)) throw new Error(`Missing normalizer contract: ${needle}`);
}

const api = fs.readFileSync(path.join(__dirname, '../src/services/posApi.ts'), 'utf8');
for (const needle of ['get_all_products', 'normalizeProducts', 'getCategories', 'getCaseSeries', 'getCaseTypes', 'getVariantStocks']) {
  if (!api.includes(needle) && needle !== 'get_all_products') {
    throw new Error(`Missing catalog API feature: ${needle}`);
  }
}

const config = fs.readFileSync(path.join(__dirname, '../src/config/backend.ts'), 'utf8');
if (!config.includes('liveReadsEnabled: true')) throw new Error('Read-only production reads are not enabled');
if (!config.includes('liveWritesEnabled: false')) throw new Error('Production writes must stay disabled');
console.log('catalog normalizer contract ok');
