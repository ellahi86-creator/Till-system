const fs = require('fs');

const checkout = fs.readFileSync('src/domain/checkout.ts', 'utf8');
const order = fs.readFileSync('src/services/orderService.ts', 'utf8');
const receipt = fs.readFileSync('src/services/receipt.ts', 'utf8');
const printer = fs.readFileSync('src/services/printerService.ts', 'utf8');
const sales = fs.readFileSync('src/screens/SalesScreen.tsx', 'utf8');
const modal = fs.readFileSync('src/components/CheckoutModal.tsx', 'utf8');
const backend = fs.readFileSync('src/config/backend.ts', 'utf8');

function assert(value, message) { if (!value) throw new Error(message); }

assert(checkout.includes("PaymentMethod = 'Cash' | 'Card' | 'Split'"), 'cash/card/split payment model missing');
assert(checkout.includes('changeDue'), 'change due calculation missing');
assert(order.includes('totalDiscount'), 'recovered totalDiscount field missing');
assert(order.includes('cardAmount'), 'recovered cardAmount field missing');
assert(order.includes('cashAmount'), 'recovered cashAmount field missing');
assert(order.includes('paymentMethod'), 'recovered paymentMethod field missing');
assert(order.includes('receiptNotes'), 'recovered receiptNotes field missing');
assert(order.includes('variantId'), 'variant ID must be carried into sale payload');
assert(receipt.includes('Order Number:'), 'receipt must carry order number');
assert(receipt.includes('Tendered Amount:'), 'receipt must carry tendered amount');
assert(receipt.includes('Change Due:'), 'receipt must carry change due');
assert(receipt.includes('THANK YOU!'), 'receipt footer missing');
assert(printer.includes('EpsonNetworkPrinterModule'), 'Epson native module boundary missing');
assert(printer.includes('printText'), 'recovered printText bridge missing');
assert(backend.includes('liveWritesEnabled: false'), 'production writes must stay blocked');
assert(order.includes('Production order submission is blocked'), 'order write safety block missing');
assert(sales.includes('selectVariant'), 'variant-aware basket selection missing');
assert(modal.includes('Receipt Preview'), 'checkout receipt preview missing');
assert(modal.includes('Confirm Order'), 'checkout confirmation UI missing');

console.log('checkout recovery contract tests passed');
