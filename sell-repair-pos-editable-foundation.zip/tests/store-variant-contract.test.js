const fs = require('fs');

const session = fs.readFileSync('src/services/session.ts', 'utf8');
const auth = fs.readFileSync('src/services/auth.ts', 'utf8');
const normalizers = fs.readFileSync('src/services/normalizers.ts', 'utf8');
const posApi = fs.readFileSync('src/services/posApi.ts', 'utf8');
const sales = fs.readFileSync('src/screens/SalesScreen.tsx', 'utf8');
const routes = fs.readFileSync('src/services/recoveredRoutes.ts', 'utf8');

function assert(value, message) {
  if (!value) throw new Error(message);
}

assert(session.includes('user.storeId'), 'Session must recover direct user.storeId');
assert(auth.includes('storeId: extractStoreId'), 'Login session must persist recovered store ID');
assert(routes.includes("storeByIdPrefix: 'stores/'"), 'Store-by-ID production prefix must be mapped');
assert(posApi.includes('getCurrentStore'), 'Read-only current-store loader missing');
assert(posApi.includes('getProductVariants'), 'Read-only product variant loader missing');
assert(normalizers.includes("'totalStock'"), 'Variant normalizer must map totalStock');
assert(normalizers.includes("'modelName'"), 'Variant normalizer must map modelName');
assert(normalizers.includes("'modelNumber'"), 'Variant normalizer must map modelNumber');
assert(normalizers.includes("'colorName'"), 'Variant normalizer must map colorName');
assert(normalizers.includes("'result'"), 'Variant normalizer must accept response.data.result');
assert(sales.includes('LIVE CATALOGUE + STOCK • WRITES BLOCKED'), 'UI must clearly keep writes blocked');
assert(sales.includes('View variants'), 'Sales screen must expose live variant stock');

console.log('store/variant recovery contract tests passed');
