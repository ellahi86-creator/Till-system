const fs = require('fs');
const post = fs.readFileSync('src/services/postSale.ts', 'utf8');
const order = fs.readFileSync('src/services/orderService.ts', 'utf8');
const modal = fs.readFileSync('src/components/CheckoutModal.tsx', 'utf8');
const sales = fs.readFileSync('src/screens/SalesScreen.tsx', 'utf8');
const printer = fs.readFileSync('src/services/printerService.ts', 'utf8');
const backend = fs.readFileSync('src/config/backend.ts', 'utf8');

function assert(value, message) { if (!value) throw new Error(message); }

for (const key of ['orderNumber', 'order_number', 'number', 'invoiceNumber']) {
  assert(post.includes(key), `post-sale order number recovery missing ${key}`);
}
assert(post.includes('refreshSoldVariantStock'), 'sold stock refresh flow missing');
assert(post.includes('getProductVariants'), 'post-sale stock must refetch live variants');
assert(post.includes('buildReceiptText'), 'final receipt rebuild missing');
assert(post.includes('printReceipt'), 'post-sale Epson print boundary missing');
assert(order.includes('normalizeOrderSuccess'), 'order response must be normalized before completion');
assert(modal.includes('runPostSaleFlow'), 'checkout must run post-sale workflow');
assert(modal.includes('onCompleted'), 'checkout completion callback missing');
assert(sales.includes('setCart([])'), 'basket must clear only after successful completion');
assert(sales.includes('refreshedStock'), 'sales screen must apply refreshed stock');
assert(printer.includes('liveWritesEnabled'), 'printing must remain safety gated');
assert(backend.includes('liveWritesEnabled: false'), 'live writes must still be disabled');

console.log('post-sale recovery contract tests passed');
