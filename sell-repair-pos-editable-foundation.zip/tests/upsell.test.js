const assert = require('assert');

function normalize(value) { return (value || '').trim().toLowerCase(); }
const CASE_TERMS = ['case','cases','phone case','mobile case','cover','covers','phone cover','mobile cover'];
const PROTECTOR_TERMS = ['screen protector','screen protectors','tempered glass','tempered','glass protector'];
const containsAny = (value, terms) => terms.some(term => value === term || value.includes(term));
const isPhoneCase = p => [p.category,p.subcategory,p.name].map(normalize).filter(Boolean).some(v => containsAny(v, CASE_TERMS));
const isScreenProtector = p => [p.category,p.subcategory,p.name].map(normalize).filter(Boolean).some(v => containsAny(v, PROTECTOR_TERMS));
const shouldPrompt = (p, cart) => isPhoneCase(p) && !cart.some(line => isScreenProtector(line.product));

const phoneCase = { id:'1', name:'iPhone 16 Clear Case', category:'Cases', price:14.99 };
const protector = { id:'2', name:'iPhone 16 Tempered Glass Screen Protector', category:'Screen Protectors', price:9.99 };
const cable = { id:'3', name:'USB-C Cable', category:'Cables', price:8.99 };

assert.strictEqual(shouldPrompt(phoneCase, []), true, 'case should trigger prompt');
assert.strictEqual(shouldPrompt(cable, []), false, 'non-case should not trigger prompt');
assert.strictEqual(shouldPrompt(phoneCase, [{ product: protector, quantity: 1 }]), false, 'existing protector should suppress prompt');
console.log('Upsell tests passed: case triggers, non-case ignored, existing protector suppresses repeat prompt.');
