const fs = require('fs');
const path = require('path');

function read(rel) {
  return fs.readFileSync(path.join(__dirname, '..', rel), 'utf8');
}

const auth = read('src/services/auth.ts');
const backend = read('src/config/backend.ts');
const http = read('src/services/http.ts');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(backend.includes("https://api.sellandrepair.co.uk/api/v1"), 'production API base URL must include /api/v1');
assert(auth.includes("AUTH_ROUTE = 'account/Login'"), 'auth route must match recovered APK route');
assert(auth.includes('JSON.stringify({ email, password: credentials.password })'), 'login body must contain email/password');
assert(auth.includes('access_token'), 'login must map access_token');
assert(auth.includes('refresh_token'), 'login must map refresh_token');
assert(auth.includes('data.user'), 'login must map user');
assert(http.includes('`Bearer ${session.accessToken}`'), 'authenticated reads must use Bearer access token');
assert(backend.includes('liveWritesEnabled: false'), 'production writes must remain disabled');

console.log('auth contract tests passed');
