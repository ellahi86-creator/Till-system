const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '../src/services/stockQuery.ts'), 'utf8');
for (const needle of ['productId=', 'storeId=', 'variantId=', 'encodeURIComponent']) {
  if (!src.includes(needle)) throw new Error(`Missing safe stock query fragment: ${needle}`);
}
const api = fs.readFileSync(path.join(__dirname, '../src/services/posApi.ts'), 'utf8');
if (!api.includes("if (!query) throw new Error")) throw new Error('Stock lookup can run without an identifier');
console.log('stock query contract ok');
