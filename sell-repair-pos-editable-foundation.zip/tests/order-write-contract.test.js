const fs = require('fs');
const service = fs.readFileSync('src/services/orderService.ts', 'utf8');
const checkout = fs.readFileSync('src/domain/checkout.ts', 'utf8');
const routes = fs.readFileSync('src/services/recoveredRoutes.ts', 'utf8');
const backend = fs.readFileSync('src/config/backend.ts', 'utf8');

function assert(value, message) { if (!value) throw new Error(message); }

for (const field of [
  'subTotal', 'discount', 'discountAmount', 'itemDiscountAmount', 'totalDiscount',
  'grandTotal', 'cardAmount', 'cashAmount', 'changeDueAmount', 'tenderedAmount',
  'paymentMethod', 'notes', 'status', 'items'
]) assert(service.includes(field), `missing recovered order field ${field}`);

for (const field of ['sellPrice', 'quantity', 'totalPrice', 'variantId', 'purchasedPrice'])
  assert(service.includes(field), `missing recovered item field ${field}`);

assert(service.includes("RECOVERED_CREATE_ORDER_PATH = 'orders/'"), 'create-order route not recovered');
assert(routes.includes("createOrder: 'orders/'"), 'route catalogue missing create order');
assert(routes.includes("orderList: 'orders?'"), 'route catalogue missing order list');
assert(routes.includes("orderDetailsByNumber: 'orders/details?number='"), 'route catalogue missing order details');
assert(service.includes("method: 'POST'"), 'order write must be POST');
assert(service.includes('Authorization: `Bearer ${session.accessToken}`'), 'Bearer auth missing from order write');
assert(checkout.includes("status: input.status ?? 'completed'"), 'checkout status mapping missing');
assert(backend.includes('liveWritesEnabled: false'), 'production writes must remain disabled');

console.log('order write recovery contract tests passed');
